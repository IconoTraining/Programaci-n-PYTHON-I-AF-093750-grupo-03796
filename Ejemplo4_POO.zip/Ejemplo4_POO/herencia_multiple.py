class Animal:
    def __init__(self, nombre, edad):
        self.__nombre = nombre
        self.__edad = edad
        
    def info(self):
        return "Nombre: " + self.__nombre + " Edad: " + str(self.__edad)
    
    
class ProductoVenta:
    def __init__(self, codigo, precio):
        self.__codigo = codigo
        self.__precio = precio
        
    def info(self):
        return "Codigo: " + self.__codigo + " Precio: " + str(self.__precio)
    
    
# herencia multiple
class Perro(Animal, ProductoVenta):
    def __init__(self, nombre, edad, codigo, precio, vacunado, sexo):
        Animal.__init__(self,nombre, edad)
        ProductoVenta.__init__(self,codigo,precio)
        self.__vacunado = vacunado
        self.__sexo = sexo
        
    def info(self):
        return Animal.info(self) + ProductoVenta.info(self) + " Vacunado: " + str(self.__vacunado) + " Sexo: " + self.__sexo
    
    
# Crear el objeto perro
perro = Perro("Fifi", 4, "PE-001", 225, True, "Macho")
print(perro.info())