class Direccion:
    def __init__(self, calle, numero, poblacion):
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        
    def mostrar(self):
        # Mayor, 5 (Madrid)
        return self.calle + ", " + str(self.numero) + " (" + self.poblacion + ")"


class Persona:
    
    def __init__(self, nombre, edad, direccion) :
        self.nombre = nombre
        self.edad = edad 
        self.direccion = direccion  
    
    def mostrarInfo(self) :
        print("Hola, me llamo {}, tengo {} años y vivo en {}".format(self.nombre, self.edad, self.direccion.mostrar()))
 

# Crear la direccion de Juan
dir = Direccion("Mayor", 5, "Madrid")       

# Crear objetos de Persona
juan = Persona("Juan", 27, dir)
maria = Persona("Maria", 35, Direccion("Alcala", 37, "Madrid"))

# Invocar a los recursos de un objeto
juan.mostrarInfo()
maria.mostrarInfo()

# los atributos son publicos
juan.direccion = Direccion("Diagonal",127,"Barcelona")
juan.mostrarInfo()