class Persona:
    
    def __init__(self, nombre, edad) :
        self.nombre = nombre
        self.edad = edad   
    
    def mostrarInfo(self) :
        print("Hola, me llamo", self.nombre, "y tengo", self.edad, "años")
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        

# Crear objetos de Persona
juan = Persona("Juan", 27)
maria = Persona("Maria", 35)

# Invocar a los recursos de un objeto
juan.mostrarInfo()
maria.mostrarInfo()

# los atributos son publicos
juan.edad = 28
juan.mostrarInfo()