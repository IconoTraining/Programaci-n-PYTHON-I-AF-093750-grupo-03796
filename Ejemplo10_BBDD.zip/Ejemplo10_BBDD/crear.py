'''
    En este archivo generamos la estructura de la BBDD
'''

import sqlite3

# crear la BBDD
# Abrir una conexion a la BBDD, si no existe la crea
conexion = sqlite3.connect("tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

# Crear la tabla
cursor.execute("CREATE TABLE PRODUCTOS (codigo INTEGER PRIMARY KEY, descripcion TEXT, precio REAL)")

# IMPORTANTE HACER EL COMMIT
conexion.commit()

# cerrar la conexion
conexion.close()