# CRUD
# C -> Create  -- Insert
# R -> Read    -- Select
# U -> Update  -- Update
# D -> Delete  -- Delete

import sqlite3

# Abrir una conexion a la BBDD, si no existe la crea
conexion = sqlite3.connect("tienda.db")

# Obtener un cursor
cursor = conexion.cursor()


'''  *********   Insertar datos   ********  '''
# insertar un registro
#cursor.execute("INSERT INTO PRODUCTOS values (1, 'Pantalla 17 pulgadas', 89.95)")

# insertar varios registros a la vez
lista = [(2, 'Teclado', 29.50), (3, 'Raton', 15.0), (4, 'Impresora', 120.80)]
sql = "INSERT INTO PRODUCTOS values (?,?,?)"
#cursor.executemany(sql,lista)

# Es importante hacer el commit
conexion.commit()


'''  *********   Consultas   ********  '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall()  # recoger los resultados obtenidos
for prod in productos:
    print(prod)
print("-------  FIN  -------")

# mostrar todos los productos con precio inferior a 50€
cursor.execute("select * from PRODUCTOS where precio < 50")
productos = cursor.fetchall()  # recoger los resultados obtenidos
for prod in productos:
    print(prod)
print("-------  FIN  -------")

# mostrar los productos ordenados por descripcion
cursor.execute("select * from PRODUCTOS order by descripcion")
productos = cursor.fetchall()  # recoger los resultados obtenidos
for prod in productos:
    print(prod)
print("-------  FIN  -------")

# mostrar los productos cuya descripcion comience por R
cursor.execute("select * from PRODUCTOS where descripcion LIKE 'R%' ")
productos = cursor.fetchall()  # recoger los resultados obtenidos
for prod in productos:
    print(prod)
print("-------  FIN  -------")


'''  *********   Modificar datos   ********  '''
cursor.execute("UPDATE PRODUCTOS SET precio=110.50 where descripcion = 'Impresora' ")
conexion.commit()

'''  *********   Eliminar datos   ********  '''
cursor.execute("DELETE FROM PRODUCTOS where codigo = 1")
conexion.commit()


# Cerrar la conexion
conexion.close()