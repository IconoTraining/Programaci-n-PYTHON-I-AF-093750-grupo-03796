# listas: colecciones ordenadas de elementos
# en todas las colecciones los elementos pueden ser de diferentes tipos
# permite tener elementos duplicados
# Se crean con []

colores = ['rojo', 'verde', 'azul']
print(type(colores))    # list

# Mostrar la lista
print(colores)

# ordenar la lista
print(sorted(colores))

# Mostrar el color verde
print(colores[1])

# borrar el color azul
del colores[2]  # borrar por posicion
print(colores)

# concatenar a otra lista
masColores = ['blanco','negro','rosa','azul']
nuevaLista = colores + masColores
print(nuevaLista)

# borrar el color rosa
nuevaLista.remove('rosa')  # borrar por elemento
print(nuevaLista)

# Otra forma de borrar por indice
nuevaLista.__delitem__(4)
print(nuevaLista)

# Añadir un elemento al final
nuevaLista.append('naranja')
print(nuevaLista)

# Insertar un elemento en la posicion
nuevaLista.insert(0, 'marron')
print(nuevaLista)

# Como podemos tener elementos duplicados
# Contar cuantos color verde tengo
print(nuevaLista.count('verde'))

# Mostrar el indice donde se encuentra el color verde
print(nuevaLista.index("verde"))

# longitud de la lista
print(len(nuevaLista))
print(nuevaLista.__len__())

# Mostrar el ultimo elemento
print(nuevaLista[len(nuevaLista) - 1])
print(nuevaLista[-1])

# Mostrar el tercer elemento empezando por el final
print(nuevaLista[-3])

# Mostrar los 3 ultimos elementos
print(nuevaLista[-3:])

# Mostrar todos los elementos
print(nuevaLista[:])

# Mostrar elementos desde la posicion 2 hasta la 4 (ultimo excluido)
print(nuevaLista[2:4])

# Mostrar desde -4 hasta -2 (ultimo excluido)
print(nuevaLista[-4:-2])

# Siempre se recorre de izquierda a derecha. Esto no funciona, devuelve la lista vacia
print(nuevaLista[-2:-4])

# borrar todos los elementos de la lista
nuevaLista.clear()
print(nuevaLista)