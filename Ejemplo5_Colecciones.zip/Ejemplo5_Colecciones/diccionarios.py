# diccionarios: los elementos son key:value
# las claves no se pueden repetir pero los value si
# se crean con {}

# si repito una clave se sobreescribe el valor
alumnos = {"Juan":6.4, "Maria":8.3, "Luis":6.4, "Adolfo":7.1, "Maria":9.3}
print(type(alumnos))  # dict
print(alumnos)

# Mostrar solo las claves
print(alumnos.keys())

# Mostrar solo los values
print(alumnos.values())

# Mostrar si Maria esta en el diccionario
print('Maria' in alumnos)

# Accedemos a los elementos por su clave
print(alumnos.get('Luis'))
print(alumnos['Luis'])

# Eliminar a Adolfo
del alumnos['Adolfo']
print(alumnos)

# Agregar a Pedro
alumnos['Pedro'] = 4.7
print(alumnos)

# Recorrer un diccionario
for alum in alumnos:  # solo me devuelve las keys
    print(alum, alumnos[alum])
    
for item in alumnos.items(): # cada item es una tupla
    print(item)
    
for clave, valor in alumnos.items():
    print(clave, valor)
    
# otras formas de crear diccionarios
otro = dict([("Luis",8.9), ("Maria",6.3), ("Adolfo",6.9)])
otroMas = dict(Luis=8.9, Maria=6.3, Adolfo=6.9)

print(otro)
print(otroMas)