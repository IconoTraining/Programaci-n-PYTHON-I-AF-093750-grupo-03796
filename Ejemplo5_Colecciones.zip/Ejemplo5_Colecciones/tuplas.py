# tuplas: colecciones ordenadas pero inmutables
# si se permiten elementos duplicados
# se crean con ()
# Ejemplos de uso: dias de la semana, meses del año, estado civil, puntos cardinales

dias = ("lunes","martes","miercoles","jueves","viernes","sabado","domingo")
print(type(dias))  # tuple

# mostrar todos los elementos
print(dias)

# Recorrer una tupla
for dia in dias:
   print(dia) 
   
# Mostrar el miercoles
print(dias[2])

# Intentamos borrar el lunes
# TypeError: 'tuple' object doesn't support item deletion
# del dias[0]

# Intento concatenar tuplas
# TypeError: can only concatenate tuple (not "str") to tuple
# otra_tupla = dias + ("otro_sabado")

# Si puedo concatenar mientas que no sean de tipo str
numeros = (1,2,3,4,5)
otra_tupla = dias + numeros
print(otra_tupla)

# Tampoco puedo modificar elementos
# TypeError: 'tuple' object does not support item assignment
#dias[0] = "otro_sabado"
#dias[0] = dias[0].upper()

# contar cuantos lunes hay?
print(dias.count('lunes')) 

# Dime en que posicion esta el viernes
print(dias.index('viernes'))

# longitud
print(len(dias))
print(dias.__len__())

for i in range(len(dias)):
    print(dias[i])