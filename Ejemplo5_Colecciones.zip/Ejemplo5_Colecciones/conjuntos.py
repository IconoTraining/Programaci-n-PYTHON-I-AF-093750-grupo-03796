# conjuntos: colecciones sin orden, no podemos usar indices
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada
# Permite elementos de diferentes tipos
# Se crean con {}

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(type(frutas))   # set

# Mostrar todas las frutas
print(frutas)

# comprobar si tengo fresas
print('fresas' in frutas)

# agregamos fresas
frutas.add('fresas')
print(frutas)

# eliminar platano
frutas.remove('platano')
print(frutas)

# longitud
print(len(frutas))
print(frutas.__len__())

'''************ operaciones con conjuntos *************'''
numeros1 = {1,2,3,4,5,6,7,8,9}
numeros2 = {0,2,4,6,8,10}

# interseccion de conjuntos: elementos comunes en ambos
print(numeros1.intersection(numeros2))
print(numeros1 & numeros2)

# diferencia de conjuntos: mostrar los elementos de un conjunto que no estan en el otro
# mostrar los elementos de numeros1 que no estan en numeros2
print(numeros1.difference(numeros2))
print(numeros1 - numeros2)

# lo mismo pero al reves
print(numeros2.difference(numeros1))
print(numeros2 - numeros1)

# que elementos estan fuera de la interseccion
print(numeros1.symmetric_difference(numeros2))
print(numeros1 ^ numeros2)

# borrar los elementos de numeros1 que esten en numeros2
numeros1.difference_update(numeros2)
print(numeros1)
print(numeros2)

''' ***************   compresion de listas  ************* '''
def filtrar():
    y = set()  # llamo al constructor de set
    for letra in 'abracadabra':
        if letra not in 'abc':
            y.add(letra)
    return y

x = filtrar()
print(x)

# Esto lo podemos hacer en una sola linea
x =  {letra for letra in 'abracadabra' if letra not in 'abc'}
print(x)