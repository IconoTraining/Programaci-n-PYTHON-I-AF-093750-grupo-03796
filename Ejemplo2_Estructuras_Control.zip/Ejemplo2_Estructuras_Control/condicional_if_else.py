# Solicitar un numero entre 1 y 10 al usuario
# comprobar si es menor de 1
# comprobar si el mayor que 10
# si es correcto, mostrar un mensaje

numero = int(input("Introduce numero (1-10): "))

# Version 1
if numero < 1 :
    print("No puede ser menor que 1")
else:
    if numero > 10 :
        print("No puede ser mayor que 10")
    else :
        print("Numero correcto")
        

# Version 2
if numero < 1 :
    print("No puede ser menor que 1")
elif numero > 10 :
    print("No puede ser mayor que 10")
else :
    print("Numero correcto")