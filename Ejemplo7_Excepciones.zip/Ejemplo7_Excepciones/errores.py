# try-except-else-finally

try:
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor: "))
    division = numero1 / numero2
except ZeroDivisionError as error:
    print("No se puede dividir por cero", error)
except ValueError as ex:
    print("El valor introducido no es numerico", ex)
except Exception as ex:
    print("Ha ocurrido un error", ex)
else:
    # Se ejecuta cuando no hay ningun error
    print("Resultado:", division)
finally:
    # Siempre se ejecuta, haya o no excepciones
    print("*****  FIN  *****")