from ntpath import join


texto = "bienvenidos al curso de Python"
print(texto)

print(texto.capitalize())
print(texto.upper())
print(texto.lower())

print(texto.isalnum()) # False porque tiene espacios en blanco
print("Pepito".isalnum())
print("12345".isalnum())

print(texto.isalpha()) # False porque tiene espacios en blanco
print("Pepito".isalpha())

print(texto.isdigit()) # False
print("12345".isdigit())

print(texto.isupper())
print(texto.islower())

ejemplo = "     lunes     "
print(ejemplo, end=".\n")
print(ejemplo.lstrip(), end=".\n")
print(ejemplo.rstrip(), end=".\n")
print(ejemplo.strip(), end=".\n")

print("Longitud:", len(texto))
print("Longitud:", texto.__len__())

print("Max:", max(texto))
print("Min:", min(texto))

print(texto.replace('e', 'E'))

palabras = texto.split();
print(palabras)
print("-".join(palabras))

fecha = "20/6/2022"
datos = fecha.split("/")
print("Dia:", datos[0])
print("Mes:", datos[1])
print("Año:", datos[2])

print(texto.swapcase())