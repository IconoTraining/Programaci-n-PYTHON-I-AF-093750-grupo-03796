'''
    solicitar numeros al usuario
    mostrar suma, resta, multiplicacion, division, modulo, potencia
'''

numero1 = int(input("Introduce un numero: "))
numero2 = int(input("Introduce un numero: "))

print("Suma: ", numero1 + numero2)
print("Resta: ", numero1 - numero2)
print("Multiplicacion: ", numero1 * numero2)
print("Division: ", round(numero1 / numero2, 2))
print("Modulo: ", numero1 % numero2)
print("Potencia: ", numero1 ** numero2)
print("Division entera: ", numero1 // numero2)
