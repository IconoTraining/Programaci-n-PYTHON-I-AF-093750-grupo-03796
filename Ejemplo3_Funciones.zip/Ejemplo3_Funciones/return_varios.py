# crear una funcion que recibe un texto y devuelve:
#   - el texto en mayusculas
#   - el texto en minusculas
#   - la longitud del texto

def procesarTexto(texto):
    mayusculas = texto.upper() 
    minusculas = texto.lower()
    longitud = len(texto)
    return mayusculas, minusculas, longitud

# recuperamos con multiples variables
txtMay, txtMin, txtLen = procesarTexto("Hola, que tal?")
print(txtMay)
print(txtMin)
print(txtLen)

# recuperar con una lista
lista = procesarTexto("Hola, que tal?")
for dato in lista:
    print(dato)