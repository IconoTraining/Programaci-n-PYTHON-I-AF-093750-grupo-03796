# Funcion con numero variable de argumentos
def sumar(*numeros):
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(6))
print(sumar(2,5))
print(sumar(3,9,6))
print(sumar(3,1,5,9,7,2))


# crear una funcion que recibe el nombre y las notas de cada alumno
# utilizando la funcion sumar() calcular la nota media
# la funcion devuelve el nombre en mayusculas y la nota media
def procesarNotas(nombre, *notas):
    notaMedia = sumar(*notas) / len(notas)
    return nombre.upper(), notaMedia

print(procesarNotas("Juan", 4,7,5,9))
print(procesarNotas("Maria", 3,8))
print(procesarNotas("Pedro", 8,9,7,10))