def datosTrabajador(nombre, estadoCivil="Soltero", sueldo=21000):
    return nombre + " esta " + estadoCivil + " y gana " + str(sueldo)

# Formas de invocar a la funcion
print(datosTrabajador("Juan"))
print(datosTrabajador("Luis", "Separado"))
print(datosTrabajador("Maria", "Casada", 35000))

# El sueldo de Paula lo interpreta como estado civil
#print(datosTrabajador("Paula", 40000))

# solucion
print(datosTrabajador("Paula", sueldo=40000))



def concatenar(*datos, separador=" | "):
    return separador.join(datos)

print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo"))
print(concatenar("lunes","martes","miercoles","jueves","viernes","sabado","domingo", separador=" - "))