# declarar funciones
def saludar(nombre):
    print("Hola", nombre, "que tal?")

def despedir():
    return "Adios. Hasta la proxima"


# invocar o llamar a una funcion
saludar("Pepito")

mensaje = despedir()
print(mensaje)
print(despedir())