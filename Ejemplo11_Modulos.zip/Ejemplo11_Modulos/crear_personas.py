# Primera forma de importar el modulo
'''
import persona

# sintaxis:    modulo.Clase
p1 = persona.Persona("Luis",45)
p1.mostrarInfo()
'''

# Segunda forma
'''
from persona import Persona
p1 = Persona("Paula", 22)
p1.mostrarInfo()
'''

# Tercera forma
from persona import Persona as Person
p1 = Person("Irene", 34)
p1.mostrarInfo()
