import pickle

nombres = ["Juan", "Maria", "Pedro", "Laura", "Luis"]
fichero = open("Ejemplo9_Ficheros_Binarios/binario.pckl", "wb")
pickle.dump(nombres, fichero)
fichero.close()