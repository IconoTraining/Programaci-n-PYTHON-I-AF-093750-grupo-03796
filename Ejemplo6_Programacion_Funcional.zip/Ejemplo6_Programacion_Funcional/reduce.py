# La funcion reduce le pasamos una coleccion y
# retorna una solo resultado
# la funcion recibe 2 parametros:
#       - el primero actua como acumulador
#       - el segundo es el valor recibido
# sintaxis:   reduce(funcion, coleccion)

'''  Para utilizar reduce es necesario importarlo  '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]

def sumar(acum, num):
    return acum + num

print("Suma: ", reduce(sumar, numeros))


# Ejemplo 2
nombres = ["Juan","Maria","Pablo"]

def concatenar(resultado, nombre):
    return resultado.upper() + "-" + nombre.upper()

print(reduce(concatenar,nombres))