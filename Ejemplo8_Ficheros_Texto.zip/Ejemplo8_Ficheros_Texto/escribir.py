# Abrir el fichero en modo escritura

# ruta absoluta
# fichero = open("/Users/anaisabelvegascaceres/Desktop/Python_BBVA_20_Junio/Ejemplo8_Ficheros_Texto/fichero.txt", "at")

# ruta relativa
fichero = open("Ejemplo8_Ficheros_Texto/fichero.txt", "wt", encoding="utf-8")

texto = "Esto es una prueba"
fichero.write(texto)

# cerrar el fichero
fichero.close()